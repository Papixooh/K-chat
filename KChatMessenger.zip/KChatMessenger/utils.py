import os
from datetime import datetime

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'mp3', 'mp4', 'wav'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_icon(file_path):
    """Return appropriate icon class for file type"""
    if not file_path:
        return 'fas fa-file'
    
    extension = file_path.rsplit('.', 1)[1].lower() if '.' in file_path else ''
    
    icon_map = {
        'pdf': 'fas fa-file-pdf',
        'doc': 'fas fa-file-word',
        'docx': 'fas fa-file-word',
        'txt': 'fas fa-file-alt',
        'jpg': 'fas fa-file-image',
        'jpeg': 'fas fa-file-image',
        'png': 'fas fa-file-image',
        'gif': 'fas fa-file-image',
        'mp3': 'fas fa-file-audio',
        'wav': 'fas fa-file-audio',
        'mp4': 'fas fa-file-video'
    }
    
    return icon_map.get(extension, 'fas fa-file')

def format_timestamp(timestamp):
    """Format timestamp for display"""
    now = datetime.utcnow()
    diff = now - timestamp
    
    if diff.days > 0:
        return timestamp.strftime('%m/%d/%Y')
    elif diff.seconds > 3600:
        return timestamp.strftime('%I:%M %p')
    else:
        return timestamp.strftime('%I:%M %p')

def get_message_status_icon(message):
    """Get appropriate status icon for message"""
    if message.is_read:
        return 'fas fa-check-double text-primary'
    else:
        return 'fas fa-check text-muted'
