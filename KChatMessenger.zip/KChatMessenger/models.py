from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    bio = db.Column(db.Text)
    profile_picture = db.Column(db.String(200), default='default_avatar.svg')
    is_online = db.Column(db.Boolean, default=False)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy='dynamic')
    received_messages = db.relationship('Message', foreign_keys='Message.recipient_id', backref='recipient', lazy='dynamic')
    group_memberships = db.relationship('GroupMember', backref='user', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_contacts(self):
        # Get all users who have exchanged messages with this user
        contacts_ids = set()
        
        # Users who sent messages to this user
        for message in self.received_messages:
            contacts_ids.add(message.sender_id)
        
        # Users who received messages from this user
        for message in self.sent_messages:
            contacts_ids.add(message.recipient_id)
        
        return User.query.filter(User.id.in_(contacts_ids)).all()
    
    def get_conversation_with(self, other_user_id):
        return Message.query.filter(
            ((Message.sender_id == self.id) & (Message.recipient_id == other_user_id)) |
            ((Message.sender_id == other_user_id) & (Message.recipient_id == self.id))
        ).filter(Message.group_id.is_(None)).order_by(Message.timestamp).all()
    
    def __repr__(self):
        return f'<User {self.username}>'

class Group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    group_picture = db.Column(db.String(200), default='default_group.svg')
    
    # Relationships
    creator = db.relationship('User', backref='created_groups')
    members = db.relationship('GroupMember', backref='group', lazy='dynamic', cascade='all, delete-orphan')
    messages = db.relationship('Message', backref='group', lazy='dynamic')
    
    def get_members(self):
        return User.query.join(GroupMember).filter(GroupMember.group_id == self.id).all()
    
    def is_member(self, user_id):
        return GroupMember.query.filter_by(group_id=self.id, user_id=user_id).first() is not None
    
    def __repr__(self):
        return f'<Group {self.name}>'

class GroupMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    
    __table_args__ = (db.UniqueConstraint('group_id', 'user_id'),)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Null for group messages
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=True)  # Null for direct messages
    message_type = db.Column(db.String(20), default='text')  # text, image, file
    file_path = db.Column(db.String(200))  # For file uploads
    file_name = db.Column(db.String(200))  # Original filename
    is_read = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<Message {self.id}: {self.content[:50]}>'

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    contact_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', foreign_keys=[user_id], backref='user_contacts')
    contact_user = db.relationship('User', foreign_keys=[contact_user_id])
    
    __table_args__ = (db.UniqueConstraint('user_id', 'contact_user_id'),)
