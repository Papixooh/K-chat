// K Chat - Main JavaScript Functions

document.addEventListener('DOMContentLoaded', function() {
    initializeChat();
    initializeNotifications();
    initializeFormEnhancements();
});

// Initialize chat functionality
function initializeChat() {
    // Auto-scroll to bottom of messages
    const messagesContainer = document.getElementById('chatMessages');
    if (messagesContainer) {
        scrollToBottom(messagesContainer);
    }
    
    // Auto-resize message textarea
    const messageTextarea = document.querySelector('textarea[name="content"]');
    if (messageTextarea) {
        autoResizeTextarea(messageTextarea);
    }
    
    // Handle Enter key submission
    if (messageTextarea) {
        messageTextarea.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                const form = this.closest('form');
                if (form && this.value.trim()) {
                    form.submit();
                }
            }
        });
    }
    
    // Initialize auto-refresh for chat messages
    initializeAutoRefresh();
}

// Scroll to bottom of messages container
function scrollToBottom(container) {
    container.scrollTop = container.scrollHeight;
}

// Auto-resize textarea based on content
function autoResizeTextarea(textarea) {
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });
}

// Initialize notifications and alerts
function initializeNotifications() {
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            if (alert && alert.parentNode) {
                alert.style.opacity = '0';
                setTimeout(function() {
                    if (alert && alert.parentNode) {
                        alert.remove();
                    }
                }, 300);
            }
        }, 5000);
    });
}

// Initialize form enhancements
function initializeFormEnhancements() {
    // File input toggle
    const fileToggleBtn = document.querySelector('[onclick="toggleFileInput()"]');
    if (fileToggleBtn) {
        fileToggleBtn.removeAttribute('onclick');
        fileToggleBtn.addEventListener('click', toggleFileInput);
    }
    
    // Form validation enhancements
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('input[type="submit"], button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
                
                // Re-enable after 3 seconds as fallback
                setTimeout(function() {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = submitBtn.dataset.originalText || 'Send';
                    }
                }, 3000);
            }
        });
    });
}

// Toggle file input visibility
function toggleFileInput() {
    const fileArea = document.getElementById('fileInputArea');
    if (fileArea) {
        if (fileArea.style.display === 'none' || !fileArea.style.display) {
            fileArea.style.display = 'block';
            fileArea.style.animation = 'slideDown 0.3s ease-out';
        } else {
            fileArea.style.display = 'none';
        }
    }
}

// Auto-refresh messages functionality
function initializeAutoRefresh() {
    // Only refresh if we're on a chat page with messages
    if (window.location.pathname.includes('/chat/') && document.getElementById('chatMessages')) {
        setInterval(function() {
            refreshMessages();
        }, 10000); // Refresh every 10 seconds
    }
}

// Refresh messages (simple reload for now)
function refreshMessages() {
    // In a production app, this would use AJAX to fetch new messages
    // For now, we'll do a simple page refresh if no form is being filled
    const activeElement = document.activeElement;
    const messageTextarea = document.querySelector('textarea[name="content"]');
    
    // Don't refresh if user is typing
    if (activeElement !== messageTextarea || !messageTextarea.value.trim()) {
        // Store scroll position
        const messagesContainer = document.getElementById('chatMessages');
        const wasAtBottom = messagesContainer ? 
            (messagesContainer.scrollTop + messagesContainer.clientHeight >= messagesContainer.scrollHeight - 10) : false;
        
        // Simple refresh for MVP
        if (wasAtBottom) {
            window.location.reload();
        }
    }
}

// Utility function to show toast notifications
function showToast(message, type = 'info') {
    const toastContainer = getOrCreateToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show toast-notification`;
    
    // Create message text node (safe from XSS)
    const messageNode = document.createTextNode(message);
    toast.appendChild(messageNode);
    
    // Create close button safely
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'btn-close';
    closeButton.setAttribute('data-bs-dismiss', 'alert');
    toast.appendChild(closeButton);
    
    toastContainer.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(function() {
        if (toast && toast.parentNode) {
            toast.remove();
        }
    }, 3000);
}

// Get or create toast container
function getOrCreateToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 300px;
        `;
        document.body.appendChild(container);
    }
    return container;
}

// Search functionality
function initializeSearch() {
    const searchForm = document.querySelector('form[action*="search"]');
    if (searchForm) {
        const searchInput = searchForm.querySelector('input[name="q"]');
        if (searchInput) {
            // Add debounced search
            let searchTimeout;
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(function() {
                    if (searchInput.value.trim().length > 2) {
                        // In a real app, this would trigger AJAX search
                        console.log('Searching for:', searchInput.value);
                    }
                }, 500);
            });
        }
    }
}

// Mobile responsive helpers
function initializeMobileFeatures() {
    // Add mobile-specific behaviors
    if (window.innerWidth <= 768) {
        // Handle mobile chat sidebar
        const chatSidebar = document.querySelector('.chat-sidebar');
        const chatMain = document.querySelector('.chat-main');
        
        if (chatSidebar && chatMain) {
            // Add toggle button for mobile
            addMobileSidebarToggle();
        }
    }
}

// Add mobile sidebar toggle
function addMobileSidebarToggle() {
    const chatHeader = document.querySelector('.chat-header');
    if (chatHeader && window.innerWidth <= 768) {
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'btn btn-outline-secondary btn-sm me-2';
        toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
        toggleBtn.addEventListener('click', function() {
            const sidebar = document.querySelector('.chat-sidebar');
            if (sidebar) {
                sidebar.classList.toggle('show');
            }
        });
        
        chatHeader.insertBefore(toggleBtn, chatHeader.firstChild);
    }
}

// Initialize all features
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
    initializeMobileFeatures();
});

// Handle window resize
window.addEventListener('resize', function() {
    // Reinitialize mobile features if needed
    if (window.innerWidth <= 768) {
        initializeMobileFeatures();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K for quick search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="q"]');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Escape to close mobile sidebar
    if (e.key === 'Escape') {
        const sidebar = document.querySelector('.chat-sidebar.show');
        if (sidebar) {
            sidebar.classList.remove('show');
        }
    }
});

// Online status simulation (for demo purposes)
function updateOnlineStatus() {
    // In a real app, this would connect to WebSocket or polling
    const statusIndicators = document.querySelectorAll('.status-indicator.online');
    statusIndicators.forEach(function(indicator) {
        // Add subtle pulse animation
        indicator.style.animation = 'pulse 2s infinite';
    });
}

// CSS for pulse animation (injected via JS)
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }
    
    .toast-notification {
        margin-bottom: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
`;
document.head.appendChild(style);

// Initialize online status updates
setInterval(updateOnlineStatus, 5000);
