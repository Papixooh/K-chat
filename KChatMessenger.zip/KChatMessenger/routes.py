import os
from datetime import datetime
from urllib.parse import urlparse
from flask import render_template, flash, redirect, url_for, request, current_app
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.utils import secure_filename
from app import app, db
from models import User, Message, Group, GroupMember, Contact
from forms import LoginForm, RegistrationForm, MessageForm, ProfileForm, GroupForm, AddContactForm
from utils import allowed_file, get_file_icon

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            user.is_online = True
            user.last_seen = datetime.utcnow()
            db.session.commit()
            next_page = request.args.get('next')
            if not next_page:
                next_page = url_for('chat')
            else:
                # Validate the next_page URL to prevent open redirect attacks
                parsed_url = urlparse(next_page)
                if parsed_url.netloc:  # If netloc exists, it's an external URL
                    next_page = url_for('chat')
            return redirect(next_page)
        flash('Invalid username or password')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            full_name=form.full_name.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    current_user.is_online = False
    current_user.last_seen = datetime.utcnow()
    db.session.commit()
    logout_user()
    return redirect(url_for('index'))

@app.route('/chat')
@app.route('/chat/<int:user_id>')
@app.route('/chat/group/<int:group_id>')
@login_required
def chat(user_id=None, group_id=None):
    form = MessageForm()
    contacts = current_user.get_contacts()
    groups = Group.query.join(GroupMember).filter(GroupMember.user_id == current_user.id).all()
    
    messages = []
    chat_partner = None
    current_group = None
    
    if user_id:
        chat_partner = User.query.get_or_404(user_id)
        messages = current_user.get_conversation_with(user_id)
        form.recipient_id.data = user_id
        
        # Mark messages as read
        Message.query.filter_by(sender_id=user_id, recipient_id=current_user.id, is_read=False).update({'is_read': True})
        db.session.commit()
        
    elif group_id:
        current_group = Group.query.get_or_404(group_id)
        if not current_group.is_member(current_user.id):
            flash('You are not a member of this group.')
            return redirect(url_for('chat'))
        messages = Message.query.filter_by(group_id=group_id).order_by(Message.timestamp).all()
        form.group_id.data = group_id
    
    return render_template('chat.html', 
                         form=form, 
                         messages=messages, 
                         contacts=contacts, 
                         groups=groups,
                         chat_partner=chat_partner,
                         current_group=current_group)

@app.route('/send_message', methods=['POST'])
@login_required
def send_message():
    form = MessageForm()
    
    if form.validate_on_submit():
        # Handle file upload
        file_path = None
        file_name = None
        message_type = 'text'
        
        if form.file.data:
            file = form.file.data
            if allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Add timestamp to filename to avoid conflicts
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                filename = timestamp + filename
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                file_path = f'uploads/{filename}'
                file_name = file.filename
                message_type = 'file'
        
        # Create message
        message = Message(
            content=form.content.data,
            sender_id=current_user.id,
            message_type=message_type,
            file_path=file_path,
            file_name=file_name
        )
        
        if form.recipient_id.data:
            message.recipient_id = int(form.recipient_id.data)
            redirect_url = url_for('chat', user_id=form.recipient_id.data)
        elif form.group_id.data:
            message.group_id = int(form.group_id.data)
            redirect_url = url_for('chat', group_id=form.group_id.data)
        else:
            flash('Invalid message recipient.')
            return redirect(url_for('chat'))
        
        db.session.add(message)
        db.session.commit()
        
        return redirect(redirect_url)
    
    flash('Failed to send message.')
    return redirect(url_for('chat'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = ProfileForm()
    
    if form.validate_on_submit():
        current_user.full_name = form.full_name.data
        current_user.bio = form.bio.data
        
        # Handle profile picture upload
        if form.profile_picture.data:
            file = form.profile_picture.data
            if allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                filename = f"profile_{current_user.id}_{timestamp}{filename}"
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                current_user.profile_picture = f'uploads/{filename}'
        
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile'))
    
    # Pre-populate form
    form.full_name.data = current_user.full_name
    form.bio.data = current_user.bio
    
    return render_template('profile.html', form=form)

@app.route('/contacts', methods=['GET', 'POST'])
@login_required
def contacts():
    form = AddContactForm()
    
    if form.validate_on_submit():
        contact_user = User.query.filter_by(username=form.username.data).first()
        if contact_user and contact_user.id != current_user.id:
            # Check if contact already exists
            existing_contact = Contact.query.filter_by(
                user_id=current_user.id, 
                contact_user_id=contact_user.id
            ).first()
            
            if not existing_contact:
                contact = Contact(user_id=current_user.id, contact_user_id=contact_user.id)
                db.session.add(contact)
                db.session.commit()
                flash(f'{contact_user.full_name} added to contacts!')
            else:
                flash('User is already in your contacts.')
        else:
            flash('Cannot add yourself or user not found.')
    
    user_contacts = db.session.query(User).join(
        Contact, Contact.contact_user_id == User.id
    ).filter(Contact.user_id == current_user.id).all()
    
    return render_template('contacts.html', form=form, contacts=user_contacts)

@app.route('/groups', methods=['GET', 'POST'])
@login_required
def groups():
    form = GroupForm()
    
    if form.validate_on_submit():
        group = Group(
            name=form.name.data,
            description=form.description.data,
            created_by=current_user.id
        )
        db.session.add(group)
        db.session.flush()  # To get the group ID
        
        # Add creator as admin member
        member = GroupMember(
            group_id=group.id,
            user_id=current_user.id,
            is_admin=True
        )
        db.session.add(member)
        db.session.commit()
        
        flash(f'Group "{group.name}" created successfully!')
        return redirect(url_for('groups'))
    
    user_groups = Group.query.join(GroupMember).filter(GroupMember.user_id == current_user.id).all()
    
    return render_template('groups.html', form=form, groups=user_groups)

@app.route('/join_group/<int:group_id>')
@login_required
def join_group(group_id):
    group = Group.query.get_or_404(group_id)
    
    if not group.is_member(current_user.id):
        member = GroupMember(group_id=group_id, user_id=current_user.id)
        db.session.add(member)
        db.session.commit()
        flash(f'You joined "{group.name}"!')
    else:
        flash('You are already a member of this group.')
    
    return redirect(url_for('groups'))

@app.route('/search')
@login_required
def search():
    query = request.args.get('q', '')
    results = []
    
    if query:
        # Search in messages
        message_results = Message.query.filter(
            Message.content.contains(query),
            ((Message.sender_id == current_user.id) | (Message.recipient_id == current_user.id))
        ).order_by(Message.timestamp.desc()).limit(20).all()
        
        # Search in users
        user_results = User.query.filter(
            User.username.contains(query) | User.full_name.contains(query)
        ).filter(User.id != current_user.id).limit(10).all()
        
        results = {
            'messages': message_results,
            'users': user_results
        }
    
    return render_template('search.html', query=query, results=results)

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# Context processor to make functions available in templates
@app.context_processor
def utility_processor():
    return dict(get_file_icon=get_file_icon)
